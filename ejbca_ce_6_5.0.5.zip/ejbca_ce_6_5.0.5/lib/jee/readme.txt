
JEE6 API libraries used for building/developing EJBCA
---

Library					Source				License						Content			Usage
javaee-api-6.0-6.jar	Apache's OpenEJB	Apache License Version 2.0	JEE6 Apis		Build of EJBCA and EJB CLI
myfaces-api-2.0.23.jar  Apache's MyFaces	Apache License Version 2.0	JSF 2.0			Build of EJBCA
myfaces-impl-2.0.23.jar Apache's MyFaces	Apache License Version 2.0	JSTL 1.2		GUI Development
