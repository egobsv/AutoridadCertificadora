
Commons-x jars are apache jars (http://jakarta.apache.org/commons/index.html), License is Apache.
The jars: 
 commons-logging-1.1.1.jar 
 commons-beanutils-1.8.3.jar 
 commons-digester-1.8.jar 
 commons-el-1.0.jar 
 commons-codec-1.3.jar
 commons-collections-3.2.2.jar
 commons-fileupload-1.3.1.jar
 commons-io-1.3.2.jar
are for example used by MyFaces/FileUpload etc.

commons-configuration-1.6
commons-lang-2.5.jar is used throughout EJBCA.

commons-cli-1.0.jar is used to create nice CLI programs.

Log4j.jar is from apache, License is Apache.
The file is used for logging throughout EJBCA.
Version is 1.2.16.

bc-x jars are BouncyCastle (http://www.bouncycastle.org), License is BC (BSD like).
These jars are the cryptographic foundation in EJBCA.

Ldap.jar is from OpenLDAP and used for publishing in LDAP directories, current version is from 2009-10-07.
OpenLDAP Public License, http://www.openldap.org/software/release/license.html
 
cert-cvc-1.4.4.jar is a library for handling Card Verifiable Certificates, built from the sub project cert-cvc of EJBCA, 
originally developed by Keijo Kurkinen, and contributed to EJBCA. License is LGPL.

libidn.jar: version 0.6.9, http://www.gnu.org/software/libidn/, java library is LGPL.
