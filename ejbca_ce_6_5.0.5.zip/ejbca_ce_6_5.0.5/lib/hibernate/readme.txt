
Hibernate jars are from Hibernate (http://hibernate.org), License is LGPLv2.1.
This applies to all hibernate and javassist jars in this directory.

Some hibernate jars are under Apache/MIT/BSD/CDDL like licenses and have a license file included. These jars are:
- antlr
- dom4j
