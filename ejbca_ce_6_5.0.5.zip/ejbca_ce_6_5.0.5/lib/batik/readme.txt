
Batik jars are apache jars, License is Apache.
The jars are used for creating printouts for labels etc used by the hard token interface.
The xerces and xml-jars are used by batik.

The current version of Batik used is batik 1.7.
